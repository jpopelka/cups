README - CUPS Printer Driver for Windows 6.0 - 2006-04-19
---------------------------------------------------------

INTRODUCTION

    This file describes the CUPS printer driver for Microsoft
    Windows 2000, XP, and 2003.  The driver is not compatible
    with Microsoft Windows 95, 98, 98SE, ME, or NT.

    This driver is implemented as rendering and user-interface
    modules for the Microsoft PostScript printer driver
    (PSCRIPT5.DLL and PS5UI.DLL) which is included with the
    corresponding Microsoft Windows 2000, XP, or 2003 operating
    system.

    The CUPS driver is provided under the terms of the GNU
    General Public License and may be freely modified and
    distributed under those terms. The Microsoft driver DLLs are
    not provided under the GNU GPL and you will need to contact
    Microsoft for permission to distribute copies of the driver
    to third-parties.


FEATURES

    The CUPS driver adds the following features/options to the standard
    Windows PostScript driver:

	- Support for the page-label and job-billing options


SPECIAL NOTES

    JCL options in PPD files must be sanitized in order to work
    properly with the CUPS driver.  This generally means changing
    the Adobe JCL attributes in the file to be:

        *JCLBegin: "%!PS-Adobe-3.0<0A>"
	*JCLEnd: ""
	*JCLToPSInterpreter: ""

    Any JCL option invocations should then be changed from:

        *JCLFoo Bar/Soap: "@PJL SET FOO=BAR<0A>"

    to:

        *JCLFoo Bar/Soap: "%cupsJobTicket: JCLFoo=Bar<0A>"

    If you don't make these changes, then all JCL options will
    be silently ignored when the job is printed by the server.

    The free ESP Print Pro Client for Windows software and the
    cupsaddsmb software included with CUPS 1.1.21 and higher
    automatically sanitize the PPD files for the CUPS driver.


COMPILING THE DRIVER

    You will need the current Microsoft Windows Driver
    Development Kit for Windows, which is available separately
    and as part of certain MSDN subscription packages.  The
    driver cannot, to our knowledge, be built using free
    software tools.

    Once you have the Windows DDK installed, open the Free Build
    command prompt window and type:

        cd \the\source\directory
        build /c


CHANGES IN 6.0

    - First release based upon the new Microsoft driver.
    - TrueType font embedding should now work, and all other
      reported driver crashes and rendering issues should now be
      resolved.


LEGAL STUFF

    The CUPS printer driver for Windows is Copyright 2001-2006 by
    Easy Software Products. CUPS, the CUPS logo, the Common UNIX
    Printing System, and ESP Print Pro are the trademark property
    of Easy Software Products.

    This software is provided under the terms of the GNU General
    Public License. This program is distributed in the hope that
    it will be useful, but WITHOUT ANY WARRANTY; without even
    the implied warranty of MERCHANTABILITY or FITNESS FOR A
    PARTICULAR PURPOSE.  See the "LICENSE.txt" file for more
    information.

    For commercial licensing information, please contact:

	Attn: CUPS Licensing Information
	Easy Software Products
	44141 Airport View Drive, Suite 204
	Hollywood, Maryland 20636 USA

	Voice: +1.301.373.9600
	Email: cups-info@cups.org
	WWW: http://www.cups.org/
