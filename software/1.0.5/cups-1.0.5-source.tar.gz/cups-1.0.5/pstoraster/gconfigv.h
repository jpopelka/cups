#define USE_ASM (-0)
#define USE_FPU (2-0)
#define EXTEND_NAMES 0
